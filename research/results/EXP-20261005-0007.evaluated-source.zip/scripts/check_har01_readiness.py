"""No-seed native conformance seal; activate once only after clone regression."""
import argparse
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from nextai_autoresearch.baseline_semantics import verify_required_baselines, write_preflight_certificate, verify_preflight_certificate
from nextai_autoresearch.integrity import freeze_manifest, verify_manifest
from nextai_autoresearch.ledger import read_jsonl, append_jsonl
from nextai_autoresearch.research_program import status, _study_scope
from nextai_autoresearch.utils import atomic_write_json, sha256_file, utc_now


def main(ready):
    root = Path(__file__).resolve().parents[1]
    assert root.name == "NEXTAI-VALIDATION-20261002", "Independent clone required"
    study_path = "research/plans/HAR01-FROZEN-SOURCE-SCREEN-V1.json"
    study = json.loads((root / study_path).read_text(encoding="utf-8"))
    current = status(root)
    assert current["study_path"] == study_path and not current["study_terminal"] and not current["study_expired"]
    assert not current["ready"] and not current["paid_run_pending"]
    intake = json.loads((root / "research/data_manifests/HAR01-ACQUISITION-V1.json").read_text(encoding="utf-8"))
    payload = {intake["dataset_path"]: intake["dataset_sha256"],
               "research/data/har01_native_v1/publisher.zip": intake["publisher_sha256"]}
    for path, digest in payload.items():
        assert sha256_file(root / path) == digest, path
    assert study["task_contract_sha256"] == sha256_file(root / study["task_contract_path"])
    bound = {"candidates": study["candidates"], "research_program_protocol": _study_scope(study)}
    if ready:
        full = root / "research/reviews/NEXTAI-B-319-full-regression-V1.json"
        record = json.loads(full.read_text(encoding="utf-8"))
        assert record["error"] is None
        assert record["result"]["exit_job_active_process_count"] == 0
        cases = ET.parse(full.with_suffix(".xml")).findall(".//testcase")
        failed = [(row.get("classname"), row.get("name")) for row in cases
                  if row.find("failure") is not None or row.find("error") is not None]
        assert len(cases) == 1361 and not any(row.find("skipped") is not None for row in cases)
        if record["result"]["returncode"]:
            assert record["result"]["returncode"] == 1
            assert failed == [("tests.test_protocol_v2", "test_checked_in_research_lifecycle_is_consistent")]
            fixed = root / "research/reviews/NEXTAI-B-319-affected-conformance-V1.json"
            repaired = json.loads(fixed.read_text(encoding="utf-8"))
            assert repaired["result"]["returncode"] == 0 and repaired["error"] is None
            assert repaired["result"]["exit_job_active_process_count"] == 0
            fixed_cases = ET.parse(fixed.with_suffix(".xml")).findall(".//testcase")
            assert fixed_cases and not any(any(row.find(k) is not None for k in ("failure", "error", "skipped")) for row in fixed_cases)
            assert ("tests.test_protocol_v2", "test_checked_in_research_lifecycle_is_consistent") in [(r.get("classname"), r.get("name")) for r in fixed_cases]
            assert len([r for r in fixed_cases if r.get("classname") == "tests.test_har01_analysis_contract"]) == 3
        else:
            assert failed == []
        config = root / "config/research.toml"
        text = config.read_text(encoding="utf-8")
        assert text.count('benchmark_status = "maintenance"') == 1
        config.write_text(text.replace('benchmark_status = "maintenance"', 'benchmark_status = "active"', 1), encoding="utf-8", newline="\n")
    freeze_manifest(root, overwrite=True)
    semantics = verify_required_baselines(bound, root, run_tests=True)
    write_preflight_certificate(root)
    certificate = verify_preflight_certificate(root)
    integrity = verify_manifest(root)
    assert integrity["ok"]
    receipt = {"created_at": utc_now(), "study_path": study_path, "study_sha256": sha256_file(root / study_path),
        "native_payload_sha256": payload, "independent_clone": str(root), "before_paid_seed_fit_or_registration": True,
        "integrity": integrity, "preflight_sha256": certificate["certificate_sha256"],
        "baseline_conformance_nodes": semantics["tests"], "historical_A_closed_and_B_reserves": current,
        "ready": ready, "no_metric_recipe_or_threshold_change": True}
    if ready:
        receipt["full_regression_receipt_sha256"] = sha256_file(full)
        receipt["full_regression_stdout_sha256"] = sha256_file(full.with_suffix(".stdout.txt"))
        receipt["full_regression_XML_sha256"] = sha256_file(full.with_suffix(".xml"))
        receipt["original_regression_failures_preserved"] = failed
        if failed:
            receipt["passing_affected_conformance_receipt_sha256"] = sha256_file(fixed)
            receipt["passing_affected_conformance_XML_sha256"] = sha256_file(fixed.with_suffix(".xml"))
    path = root / ("research/checks/HAR01-readiness-V1.json" if ready else "research/checks/HAR01-maintenance-seal-V1.json")
    assert not path.exists()
    atomic_write_json(path, receipt)
    if ready:
        append_jsonl(root / "research/events.jsonl", {"event": "research_program_study_ready", "created_at": utc_now(),
            "program_id": current["id"], "study_path": study_path, "study_sha256": receipt["study_sha256"],
            "receipt_path": str(path.relative_to(root)).replace("\\", "/"), "receipt_sha256": sha256_file(path)})
        assert status(root)["scoring_authorized"] is True
    print(json.dumps({"ready": ready, "integrity_ok": integrity["ok"], "semantic_nodes": len(semantics["tests"])}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--ready", action="store_true")
    main(parser.parse_args().ready)
