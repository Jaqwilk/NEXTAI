# Current cycle310 — EXP-20261004-0008 completed (2026-10-04)

PVM01-CAPACITY-EXPOSURE-V1 decision: INCONCLUSIVE comparison.
One audited attempt,five fresh paired units,16 arms,K32/128/512,updates0/1/4.
512 features and512 steps; K32/128 versus K32/512 fit support exposure.
All strong dense/cache/ridge/PCA/tree/kernel/exact retrieval controls retained.
Exact dense/cache decoder hashes fail on all5 units despite identical decisions.
Feature pairing passed; whole comparison invalid,official INCONCLUSIVE unchanged.
80/80 workers,720/720 trials. Full large-small -0.2292pp,
simultaneous98.75% CI[-0.9731,+0.5148]pp.
Large full90.1736%,UNKNOWN89.6389%;
small full90.4028%. Gates unchanged.
Trusted supervised fit phase832.068559s;
charged full workers1055.745196s /16640s. Larger fitting work paid.
Auxiliary cap1800s includes startup,failed boundary/readiness checks and all tests.
Deadline2026-10-05T00:50:36Z; no budget/history reset.
Complete corrected report:research/analyses/EXP-20261004-0008-ADDENDUM-V1.md.
Initial report preserved; exact final accounting:
research/laboratory/PVM01-CYCLE-310-COMPLETION-V1.receipt.json.
Current v5 study terminal,maintenance/scoring=false; global continuation active.
5/17 new tickets used,12 remain; old3/2655.336485s carried unchanged.
No retry,WT8–9,external model/API,novelty/economic/transfer promotion or schedule change.
No exposure improvement observed; failed identity gate cannot become DISCARD.
Next: preregister preparation-only deterministic decoder/telemetry conformance
in independent fixed-fixture children,no research data/EXP/paid retry.
Then a distinct prospective alternative/adverse task versus strongest classics.
Freeze before implementation/data; no automatic step rescue or gate relaxation.
Three-scale/full-cost comparison,independent replication and frozen fresh final remain.
No second EXP in this completed cycle. Previous sections are preserved history.

# Prospective cycle310 — capacity exposure (2026-10-04)

PVM01-CAPACITY-EXPOSURE-V1 is frozen before scientific implementation.
Same512 Fourier features and512 optimizer steps; compare K32/128 with K32/512
training exposure and frozen/shuffled/additive controls. Larger fit work is charged.
Five fresh paired units,80 workers/720 trials,unchanged task law and strong classics.
Four simultaneous98.75% primary intervals; competence/economic gates unchanged.
Start20:50:36Z,deadline2026-10-05T00:50:36Z,180s fit/204s worker,
full worker cap16640s,auxiliary1800s including106s startup.
Keep v4 maintenance/scoring=false until clone conformance,v5 freeze,preflight/readiness.
Exactly one audited EXP,no retry,WT8-9/API/schedule changes. Closed science stays fixed.
Previous sections are preserved history; continuation program remains active.

# Current cycle309 — EXP-20261004-0007 completed (2026-10-04)

One preregistered compact-feature screen:75/75 workers,675/675 trials,
five fresh paired units. Learned RFF512/512 steps full90.7778% versus
source-identical frozen90.8056%; contrast−0.0278pp simultaneous98.75% CI
[−0.4832,+0.4276]. Retained versus RFF2048−17.0556pp CI[−20.7854,−13.3257].
All four primary criteria fail; compact competence fails, dense/cache pass.
DISCARD this exact recipe; no architecture-family falsification or economic,
novelty, transfer or promotion claim. K512 full73.125%, UNKNOWN77.25%;
compact full service0.45285s versus dense cacheCPU1.44793s and ridge0.08421s;
PCA scan0.10426s and68.25KiB versus compact185KiB with lower quality.
All legal observations, fit identity, seeds and outcomes are preserved.
Fit phase383.3104s; charged full workers594.5230s /15600s. All tests, failures
and bookkeeping are append-only charged; auxiliary cap1800s, deadline23:32:56Z.
Analysis:research/analyses/EXP-20261004-0007.md; final accounting:
research/laboratory/PVM01-CYCLE-309-COMPLETION-V1.receipt.json.
Current v4 study terminal, maintenance/scoring=false; continuation stays active.
4/17 new tickets used; old3 tickets/2655.336485s carried unchanged. No retry,
WT8–9, external models/API or schedule change. Use uv run nextai lab status.
Next bounded cycle: preregister matched memory-training exposure including
K512 versus unchanged K32/128 at fixed512 features/512 steps, frozen/shuffled
controls, optimized dense and strongest classical/retrieval controls, five
fresh paired units. Freeze before implementation/data; no rescue on current D.
If not justified, choose a finite evidence-based alternative. Adverse, scaling,
replication, frozen fresh final and full economic gates remain required.
No second EXP in this completed cycle. Previous sections are preserved history.

# Prospective cycle309 — compact feature learning (2026-10-04)

PVM01-COMPACT-FEATURE-SCREEN-V1 is preregistered before implementation.
Trainable Fourier512 features through fixed delta memory versus frozen/shuffled
source-identical controls; unchanged correct transport and T-sets, no trained gate.
Five fresh paired units,75 workers/675 trials, K32/128/512, updates0/1/4.
Dense with CPU/CUDA cache and strongest ridge/PCA/tree/Nystrom/exact retrieval
remain controls. Four simultaneous98.75% primary intervals, outer economic
gates unchanged. Start19:32:56Z, deadline23:32:56Z,180s fit/204s worker,
full worker cap15600s and auxiliary1800s including startup checks.
Maintain v3 maintenance/scoring=false until clone conformance and v4 freeze,
preflight/readiness. Exactly one audited EXP, no retry,WT8-9/API/schedule change.
Closed evidence unchanged; global continuation and later adverse/final remain.
Previous sections are preserved history.

# Current cycle308 — EXP-20261004-0006 completed (2026-10-04)

One delta-memory screen:75/75 workers,675/675 trials, five fresh paired units.
Updated additive→delta39.83→100%; gain60.17pp simultaneous98.75% CI[56.90,63.43],
5/5positive. Retained contrast+0.61pp CI[−0.76,1.99] passes−2pp; both learning
contrasts≈74.82pp and all delta/dense competence gates pass.
KEEP narrow delta mechanism; no novelty, learned controller, economic/transfer
claim or architecture promotion. Delta full99.7986%, UNKNOWN99.5278%;
dense/cache and strong fitted retrieval/classics100%.
Full service delta0.8302s versus cacheCPU1.4487s and ridge0.0885s;
PCA scan0.1067s and68.25KiB versus delta473KiB. Full objective remains open.
Fit phase223.5436s, full charged workers449.7621s; all failed/valid auxiliary
checks charged append-only. Plan/result/source/runtime preserved before maintenance.
Analysis:research/analyses/EXP-20261004-0006.md. MUC and0004/0005 results unchanged.
Current study terminal, maintenance/scoring=false, continuation active.
3/17 new tickets used; old3 tickets/2655.336485s carried unchanged. No retry,
WT8–9, external models/API or schedule change. Use uv run nextai lab status.
Next bounded cycle: preregister compact learned-feature memory versus frozen
and shuffled controls, optimized dense and strongest classical/retrieval
controls; or finite evidence-based alternative review. No new implementation,
seed/data before freeze. Adverse, scaling, replication and frozen fresh final
remain required. No second EXP in this completed cycle.
Previous sections are preserved historical states.

# Prospective cycle308 — PVM01 delta-memory screen (2026-10-04)

PVM01-DELTA-MEMORY-SCREEN-V1 was frozen in Git6555a6ac before implementation.
One75-worker/675-trial study, five fresh paired units, unchanged PVM task,
K32/128/512 and update rounds0/1/4. Shared learned transport plus classical
RFF2048 memory contrasts fixed-beta1 delta versus additive writes; identical
untrained/shuffled delta controls. No learned controller or novelty claim.
Dense reference and optimized CPU/CUDA KV caches, exactNN CPU, float32 ridge,
PCA/whitening exact scan/cKDTree, old ridge/Nystrom/raw remain strong controls.
Four simultaneous98.75% primary intervals and competence gates frozen.
Original economic gates unchanged; no final or economic promotion in this screen.
Start2026-10-04T18:02:25Z; deadline2026-10-04T22:02:25Z. Full workers<=11100s,
fit<=120s/role, worker<=144s, auxiliary checks<=1800s including failed startup.
Keep maintenance/scoring=false until independent-clone conformance, source
freeze/preflight/readiness pass. Exactly one new registration/run, no retry.
Durable counter stays307 during preparation and runner advances on completion.
No WT8-9, external models/API or schedule change. Closed evidence preserved.
Continuation stays active; broader mechanism alternatives, adverse, economics,
replication and frozen fresh final remain required for the whole objective.
Previous sections below are preserved historical states.

# Current cycle307 — EXP-20261004-0005 completed after cycle306 preparation (2026-10-04)

Preparation was cycle306; the audited runner advanced durable state to307
after this single EXP. Both numbers are preserved; the completion receipt
retains the prospectively selected preparation-cycle306 identity.

PVM01-REFERENCE-V2 completed once in the independent clone:40 workers,
360 trials, five fresh paired seed/data units. Dense full answer99.9861%,
pointer/ridge99.9722%, trained fact top1=100%. Pointer minus untrained/shuffled
gains74.9861/75.0417pp; paired simultaneous97.5% intervals exclude zero,
5/5 positive. All frozen learning and dense/pointer competence gates passed.
KEEP the local screening cohort. No mechanism/economic/transfer promotion:
ridge matches pointer quality with much lower measured CPU workload cost.

Immutable plan/result: research/plans/EXP-20261004-0005.json and
research/results/EXP-20261004-0005.json; analysis:
research/analyses/EXP-20261004-0005.md. Actual supervised fit phase84.8973997s,
full charged worker226.9464477s/14400s. All auxiliary checks and the earlier
failed fixture regression are preserved and charged. Source1060/runtime282
files archived as raw bytes before maintenance. Earlier0004 failure stays intact.

Current study terminal, benchmark=v2 maintenance, scoring=false; no retry or
replacement seed. Standing continuation remains active:2/17 new tickets used,
plus prior3 consumed tickets. Budget/cycle closure is in
research/laboratory/PVM01-CYCLE-306-COMPLETION-V1.receipt.json.
Economic gates stay unchanged. Whole program goal remains unmet.
Next bounded question: preregister PVM01-DELTA-MEMORY-SCREEN-V1 with a single
source-identical delta-versus-additive memory contrast, strong optimized
classical controls and five new paired units; freeze exact recipe before code.
Ablations, three-scale matched-quality economics, adverse cases and frozen
fresh final remain required. No WT8-9, external model/API or schedule changes.

Postrun no-scoring serializer repair was preregistered separately: v2 analysis
delegates frozen calculations, normalizes unit keys and preserves existing files.
Targeted5/5 and real CLI repeated on0004/0005 passed without new fit or EXP.
Full repair closure checks are recorded in the completion receipt.

Earlier headers below are preserved historical states.

# Current cycle306 — preregistered PVM01-REFERENCE-V2 (2026-10-04)

The new bounded study was committed in 224a3ceb before v2 cohort activation.
Study: research/plans/PVM01-REFERENCE-V2.json; same immutable scientific recipe,
models, generator, metrics, thresholds and eight controls as v1. Five new paired
seed/data units are required. Consumed failed EXP-20261004-0004, its seeds,
private entropy, source, result and budget are preserved; it is never rerun.

Only the separately preregistered and tested v2 runtime path wrapper is used.
No research arrays or model fit were accessed before the new preregistration.
Cycle started 2026-10-04T16:56:06Z; deadline 2026-10-04T20:56:06Z.
One new registration, full worker wall<=14400s, fit<=240s/role,
worker<=356s, auxiliary checks<=1800s. No retry or replacement seed.
Clone conformance1075/1075 and immutable readiness passed before activation.
Benchmark=v2 active; source freeze/preflight and final doctor/gates must pass
before exactly one new audited registration/run this cycle.

The standing continuation program remains active. Competence/learning screening
does not establish a memory mechanism or full-cost advantage. Mechanism,
source-identical ablations, adverse variant, matched-quality economics at three
scales and a frozen fresh final remain later scope. Economic gates are unchanged.
No WT8-9, external model/API, final access or schedule changes.
Previous sections below are preserved historical records.

# Current cycle305 — PVM01 reference failure and no-scoring repair (2026-10-04)

EXP-20261004-0004 is preserved as failed before data generation or fit: first
worker path-binding AttributeError, 39 stopped workers, 0/360 trials, actual
research fit0 s. Charged worker wall1.4859776 s and all auxiliary checks remain
consumed. Plan/result/analysis: research/plans/EXP-20261004-0004.json,
research/results/EXP-20261004-0004.json and research/analyses/EXP-20261004-0004.md.
No same-plan retry or replacement seed. Evaluated v1 source/core remain intact.

Prospective no-scoring repair: PVM01-PATH-BINDING-REPAIR-V1 with dispatch and
raw-archive addenda. New paired_view_mutable_memory_v2 wrapper checks the
runner-private path and delegates to unchanged v1. Targeted worker/binding
regression10/10 PASS without research arrays/models/fit. Full closure checks
and exact accounting are recorded in the cycle305 completion receipt.
The corrected raw-byte archive keeps .gitattributes as .gitattributes.raw;
original archive, failed verification and immutable outcomes remain preserved.

The continuation program remains active: one new ticket consumed out of17,
plus the three previously consumed tickets. Current study is terminal; current
benchmark=v1 maintenance, scoring=false, no pending run. No new registration
or scored run is authorized by the repair itself. Economic gates are unchanged.

Next bounded cycle: preregister PVM01-REFERENCE-V2 under a new comparison
identity with the same recipe/controls/grids/gates and five fresh paired units;
validate clone, freeze/preflight/readiness, then at most one new audited EXP.
Standing continuation authority covers selection within remaining finite caps.
Mechanism, ablations, adverse variant, matched-quality three-scale economics
and frozen fresh final remain unexecuted. Whole program goal is not achieved.
No WT8-9, external model/API, final access, retry or schedule changes.

Earlier headers below are preserved historical states, not the current queue.

# Current cycle305 — PVM01-REFERENCE-V1 (2026-10-04)

Prospective study frozen in Git df0a4fd before generator/model implementation. Five independent fresh seed/data units, K32/128/512 and update rounds0/1/4 (legacy labels1/2/3, not reasoning depth), eight controls: dense Transformer, dense pointer, source-identical untrained/shuffled, identical-encoder exact NN, raw cosine, ridge and nonlinear Nyström transport. Same legal pairs and arrays; runner-private view maps are separate from model seeds.

Reference/learning/absence gates and finite training-only grids are immutable in research/plans/PVM01-REFERENCE-V1.json. One registration; no retry/final/WT8–9. Deadline2026-10-04T18:42:57.664034Z; each fit<=240s, worker<=356s, all worker wall charged to14400s study compute cap, tests<=1800s. Keep maintenance/scoring=false until clone tests, integrity/preflight and readiness pass. Whole continuation remains active; closed MUC studies unchanged.

Previous sections are preserved history.

# Current continuation overlay — preserved economic gates (2026-10-04)

Nowy program NEXTAI-CONTINUATION-20261004-V1 jest zatwierdzony: maksymalnie 17 dodatkowych rejestracji i 69344 s obliczeń, z zachowaniem 3 zużytych rejestracji i 2655.336485 s. Kontrakt: research/plans/NEXTAI-CONTINUATION-PROGRAM-V1.json. Zamknięty MUC03 i jego wyniki pozostają niezmienione. Nowa autoryzacja pozwala na zmianę receptur, uzasadniony nowy benchmark, minimalne prototypy, ablacje i replikacje; porażka jednej receptury nie zamyka programu. Nie ma potrzeby ponownego pytania o działania objęte tym zakresem.

Cykl 304 jest przygotowaniem bez scoringu, EXP lub fitu badawczego. MUC pozostaje testem technicznym: publiczny dokładny klucz umożliwia kontrolę symboliczną 100%. Zapisane sondy8192 pokazują przy K32/128/512 top1=100/95.33/80.44%, a odrzucenie nieznanego podmiotu=88.44/12.44/1.78%. Osobno diagnozujemy ranking i decyzję o braku odpowiedzi; zamknięte progi nie są zmieniane.

Analiza: research/analyses/NEXTAI-CONTINUATION-MUC-DIAGNOSIS-V1.md. Prospektywny kontrakt nowego zadania: research/plans/PVM01-TASK-CONTRACT-V1.json. Dwa surowe obserwacyjne widoki świeżych ciągłych tożsamości, jawne aktualizacje, kontrole zamrożona/permutowana i mocny transport/retrieval klasyczny mają sprawdzić wpływ uczenia. Nie implementowano generatora ani modeli i nie widziano nowych danych. Zmienne rundy aktualizacji nie oznaczają głębokości rozumowania.

Następny ograniczony cykl: prerejestracja PVM01-REFERENCE-V1 przed implementacją, pięć świeżych sparowanych jednostek train/dev, konwencjonalny dense Transformer i attention pointer oraz mocne kontrole. Zamrozić konkretną recepturę, metryki, capy i siatki klasyczne; walidować w niezależnym klonie, potem freeze/preflight/readiness i dokładnie jeden audytowany EXP. Zachować alternatywy przy nieudanej recepturze. Mechanizm, ablacje, trzy skale, trudny wariant i świeży finał pozostają dalszym zakresem programu.

Bramki ekonomiczne pozostają bez osłabienia. Cały fit i czas testów, także nieudanych, obciążają limit; nieukryty pełny koszt obejmuje alokację, parser, kopie, ingest, indeks, aktualizacje, cache, zapytanie i dekodowanie. Bez retry, WT8–9, zewnętrznych modeli/API i zmian harmonogramu. Current benchmark=maintenance, scoring=false. Użyj uv run nextai lab status do weryfikacji kolejki i rozliczenia.

Poniżej zachowano wcześniejsze sekcje jako historię; nie zastępują tej autoryzacji. Stałe niezmienniki naukowe i techniczne nadal obowiązują.

# Scientific protocol v3 — scoped evidence, verified measurement

## Current authority — finite autonomous research program MUC03 (2026-10-04)

The user authorizes MUC03-AUTONOMOUS-20261004-V1: at most 20 new registration
attempts, including failures/invalidations, and 72000 s total fit, including
failed fits and conservative auxiliary test charges. The immutable contract
is research/plans/MUC03-AUTONOMOUS-PROGRAM-V1.json. Old results, attempts and
budgets stay consumed. WT 8-9, external models/APIs and schedule changes remain
forbidden. Choose studies autonomously; no further approval is needed within
this finite program. Register through `uv run nextai program register`; execute
only through `uv run nextai run --plan ...`. A paid attempt cannot be retried.

First study V1 was frozen before implementation. Its sole registration ticket
was consumed by a historical schema fixture before any plan, seed or research fit.
The prospective replacement is research/plans/MUC03-DIAG-UNDERTRAINING-V2.json;
metrics, recipe, budgets and the original deadline remain fixed. It compares hard-negative 192/768 steps, same MUC v2 model and
4096 pairs, for 5 paired fresh seed/data units. Namespace probes on the same
fresh graph separate fit, rejection and generalization. Keep maintenance until
clone conformance, integrity/preflight and readiness receipt pass. No final data
in this study. A competent stable reference precedes mechanism investment;
full-cost advantage additionally needs strong classical controls, ablations,
scaling, adverse generalization and frozen fresh final replications.

One new scored experiment per cycle. End each cycle with analysis and durable
budget accounting, then select the next bounded question under this standing
program authority. At caps or a decisive resolution, finish with a reproducible
prototype or an explicitly negative/inconclusive report. Do not call diagnostics
an architecture result. All sections below describe preserved historical scope.

## Historical state — MUC v2 hard negatives completed (2026-10-04)

The one actual five-pair comparison completed as EXP-20261004-0001 in the
independent Git clone. The immutable plan is research/plans/EXP-20261004-0001.json;
analysis: research/analyses/EXP-20261004-0001.md. Random to hard: dense top1
10.96% -> 23.11%, dense UNKNOWN 10.00% -> 23.41%; paired simultaneous intervals
include zero, positive pairs are only 3/5 and 2/5, and known false abstention
rises from 0 to 22.89%. DISCARD this exact hard-negative recipe at 4096 pairs /
192 steps; the general mechanism remains inconclusive. Symbolic control: 100%.
All 11 workers completed; trusted supervised fit total83.968 s /3600 s cap.

The stage is terminal: MUC02-HARD-NEGATIVES-DECISION, scoring=false, benchmark
maintenance. No retry, replacement seed, further registration/training, final
access, WT 8-9, new architecture or promotion is authorized. A proposed 192 vs768
hard-negative fit comparison is discussion only and requires fresh authority.
Both registrations are preserved: EXP-20261003-0001 was invalidated pre-seed;
EXP-20261004-0001 was the sole actual execution under the unchanged deadline.
Evaluated protected source and all runtime journals/logs were archived before
terminal maintenance. History, budgets and scientific invariants stay intact.
Use `uv run nextai lab status` for the verified queue. All later stage-specific
sections are historical records and do not reopen execution authority.

## Historical authority — MUC v2 hard negatives (2026-10-03)

The user authorized MUC02-HARD-NEGATIVES-20261003-V1: preregister metrics and
thresholds, minimally change only training negatives, then compare random and
hard negatives in the independent Git clone on fresh train/dev for five paired
runner seeds. The MUC v2 model, 4096 pairs and 192 steps stay fixed. Work starts
2026-10-03T21:08:25Z and stops by 2026-10-04T01:08:25Z; total fit <=3600 s.
The immutable contract is research/plans/MUC02-HARD-NEGATIVES-20261003-V1.json,
with user authority in the matching research/laboratory record. The new cohort
is mutable_contact_ledger_hard_negatives_v2. No retry, WT 8-9, final/calibration
reuse, tuning, new architecture, promotion, external model/API or schedule change.
Any worker failure or cap stops the unstarted scope and preserves all outcomes.
The append-only pre-seed conformance addendum preserves invalidated
EXP-20261003-0001 and bounds one corrected preregistration before the one actual
execution; it fixes serializer fields and historical fixtures without metric,
threshold, model, data, seed, deadline or budget changes.
Use `uv run nextai lab status` for the verified queue. All sections below are
historical unless explicitly selected by this new authority.

## Historical authority — audit repair (2026-10-02)

The latest user decision authorizes AUDIT-REPAIR-20261002-V1: repair all audit
findings, validate an independent Git clone, and execute exactly one new bounded
mutable_contact_ledger_v2 calibration. See docs/CURRENT_STATUS.md and the
hash-bound research/plans/AUDIT-REPAIR-20261002-V1.json. This supersedes only
prior decision waits, not consumed attempts or scientific invariants. WT files
8-9 remain forbidden. Use `uv run nextai lab status` for the verified queue.

All stage-specific sections below are historical records, not the active queue.

### REVIEW-01 decision and proposed MUC-01 contract (2026-09-06)

REVIEW-01-20260906-V1 authorizes one preparation-only cycle and no experiment.
The proposed `MUC-01-PROPOSED-CONTRACT-V1` crosses K=32/128/512 current facts
with reasoning depth D=1/2/4, exact answers, replacements, similar distractors
and unseen relation compositions. Its one tested mechanism is local delta
correction in learned fast-weight memory; the source-identical append-only
similarity ablation, dense transformer, iterative BM25 reader and symbolic
last-write graph are mandatory controls. Full text/tokenizer/index/fit/update/
query/state costs and amortization are mandatory. The current state after
validation is REVIEW-01-DECISION: the proposal grants no implementation,
training, download, EXP registration, scoring or automatic next stage.

### WT-01 append-only correction and single replacement (2026-09-06)

WT-01-LIFECYCLE-REPLACEMENT-20260906-V1 authorizes one bounded correction of
the PC-01 closure: its Git-authenticated `research/plan_registry.jsonl` snapshot
is an immutable byte prefix, while every later byte must form complete valid
JSONL records. All other historical evidence remains whole-file immutable.
After positive append and negative mutation/truncation/reorder tests, full
regression, refreeze and preflight, exactly one replacement for invalidated
pre-seed EXP-20260905-0006 may run. Its scope is unchanged and remains limited
to visible development files 6-7; files 8-9 and retry remain forbidden.

### Prospective WT-01 visible-development diagnostic (2026-09-05)

WT-01-DEV1-20260905-V1 permits one preregistered quick factorial run after
integration tests and a new manifest/preflight freeze. The only evaluation
units are visible development files 6-7; files 8-9 remain inaccessible. The
run includes all eight source-identical R×U×C cells and the separate algebraic
VAR(2)/ARX control at every frozen K/H cell with one runner-random permutation.
The aggregate recurrence contrast and both per-file signs are descriptive
mechanism checks. They cannot establish replication, transfer, matched-quality
economics, architectural novelty or promotion. Any terminal outcome consumes
the one attempt; no tuning or automatic retry follows.

### Prospective PC-01 final adapter, no execution authority (2026-09-05)

PC-01-FINAL-PREP-V1 pins the completed v2 dev selection while measuring future
replicas under v3. The actual series must bind both evaluator identities; never
pool the dev value into the final series or fill missing historical metadata.
Mandatory v3 GPU metadata must survive both per-run and series validation.
All original learning thresholds, controls, three-seed uncertainty, source,
recipe, budgets and no-rescue rules remain unchanged. This preparation is not
permission to access final data or freeze/run the series.

Effective prospectively for LAB-RESTART-20260904-V1, authorized 2026-09-04.
The fixed research objective is unchanged. This revision is a strategic reset,
not a successful architecture result. All completed v1/v2 plans, results,
analyses, invalidations and hypothesis events remain immutable.

The full previous protocol is preserved byte-for-byte in
docs/archive/SCIENTIFIC_PROTOCOL_V2_2026-09-04.md (SHA-256
8e03fdd87da5b58dfbb3165c1225f862b255f2c11678c6128c0c137b6d5e15cd).
Historical cohorts retain those contracts and their manifests. Nothing below
retroactively changes their passing thresholds, rankings or terminal decisions.

## 1. Three questions, three evidential standards

A mechanism test asks whether learned information causes a specified effect.
It requires a source-identical intervention, a frozen/no-learning or shuffled
control, meaningful classical alternatives, a functioning positive control,
a preregistered effect size and uncertainty. It may yield a narrow positive
without a full-cost win or unrelated-family transfer.

An economics test asks whether useful matched quality costs less. It requires
the best relevant implementable controls, the full boundary, hardware and
deployment scenarios, quality guards and a replicated non-dominated result.
Lower quality at lower cost is not matched-quality superiority. Better quality
at greater cost can be a trade-off, not a cost victory.

A transfer test asks whether the learned effect generalizes as declared.
It additionally requires independent held-out units, source-identical learned
code/state/update rules, no privileged target information, and controls that
isolate transferred information. Unrelated-family transfer is required only
for a cross-family claim, not for every local learning experiment.

Do not translate any of these into a claim of general intelligence, an LLM
successor or a new scaling law from a toy task.

## 2. Positive and negative measurement controls first

Demonstrate competent learning on a task/recipe where the control is appropriate.
Freeze a feasible training budget and training/development criterion from primary
prior art; retain loss curves, optimizer steps, parameter count and device.
Do not infer failure of learning from an undertrained model or broken evaluator.
A conventional transformer is not required to learn a local update rule or
beat PPM/CTW on arbitrary tiny data to certify a learning measurement.

Check learning sensitivity, quality calculation, leakage, device synchronization
and timing independently. Intentionally broken controls must fail the intended
test without changing the evaluator to favor any candidate. Diagnostic results
are separately identified and cannot enter architecture frontiers.

## 3. Preregistration and bounded development

Before implementing a tested change, freeze its question, data/split, recipe,
controls, causal factors, effect sizes, full metrics, budget and outcome policy.
A screening study changes one fundamental factor; a factorial interaction study
may change several only when all contrasts are preregistered.

Development is allowed on declared train/dev data within a finite attempt and
compute cap. Every failed, crashed or discarded attempt remains recorded.
Select and freeze one recipe before final test access. Final test data never
guide tuning, early stopping, threshold choice or baseline selection.
After a negative final result, close the tested version. A new claim requires a
new plan, fresh holdout, disclosed earlier results and an explicit reason.

Local visible data remain screening/development evidence even if code enforces
predict-before-reveal. Strong claims require an independently isolated evaluator
or holdout the research agent cannot inspect. Never claim blindness from a name.

## 4. Fair baselines and full cost

Include a simplest heuristic, a competent learned control where relevant,
matched causal ablations and the strongest relevant classical algorithm.
A classical solver exploiting legal structure is implementable; only actual
privileged information makes an oracle. Do not require a learned algorithm to
be mathematically outside all polynomial-time statistics: that is not a valid
empirical criterion for learning or practical advantage.

Count observation acquisition, encoding, preprocessing, retrieval/index builds,
training/fit, queries, output decoding, state/cache maintenance and updates.
Separate training/R&D from inference; give an explicitly amortized workload as
well. Specify what R repeats: a query, stream or full workload. Derive break-even
reuse without disguising the workload unit. Report memory and affected bytes.

Keep operation counts/estimated FLOPs separate from measured latency, throughput
and energy. Compare same-hardware implementations as well as explicitly labeled
best-feasible deployment options. Record hardware, software, precision, threads,
synchronization, warm-up, batches, load, p50/p95, raw repeats, RAM and VRAM.
Measure batch=1 end-to-end latency separately from batched throughput. Amortized
batch time is not single-query latency. Never infer energy if it was not measured.

## 5. Replication, scale and uncertainty

At least three seeds are needed for a replicated positive, with all outcomes
retained. Seeds, permutations and repeated samples of the same physical trace
are not independent data units. Report both sources of variation explicitly.
Resample/aggregate at the independently held-out unit, not the overlapping window.

Scaling needs at least three distinct scale points for an inferential slope,
a useful range, uncertainty, fixed quality and independent variation of K and D.
K denotes stored knowledge in the target experiment, not whatever native length
is convenient. If size and task family are confounded, label the slope descriptive.
Adversarial tests attack the claimed signature, not silently change the question.

## 6. Decisions and beliefs

Use OBSERVATION / INTERPRETATION / CONFIDENCE / ALTERNATIVE EXPLANATIONS /
DECISION / NEXT DISCRIMINATING EXPERIMENT in analyses. Keep failed gates distinct
from posterior beliefs about broad principles. A crash tests implementation.
A functioning positive control plus a valid null tests the stated mechanism.
A failed control makes that comparison inconclusive until repaired on a new
version, with its failure preserved.

Legacy promising/promoted gates remain intact for historical cohorts. New
cohorts need explicit claim-specific gates in code before activation. Until then
they cannot be promoted through the legacy CLI. Architecture investment requires
replicated full-cost evidence and an adversarial test; cross-family generality
requires additional evidence. No implicit promotion from a service result.

research/BELIEFS.json is retained as the external auditor's historical draft.
Use research/laboratory/BELIEFS_POLICY.md; never reward a numerical confidence
movement, relabel classical controls to help a model, or erase inconvenient data.

## 7. Reproducibility and maintenance

Plans and results are append-only and hash-linked. Source identity comes from
the result's transitive audit hashes, not today's path contents.
Protected files, dependencies, baseline semantics and evaluator checks must pass
before and after every run. Re-freezing first archives the previous manifest.
A justified harness/data/metric change needs a new comparison identity and
fresh baselines; old and new cohorts are not directly pooled.

Git attributes specify reproducible bytes, including three documented historical
CRLF exceptions. Report freshness is based on inputs and content hashes, not mtime.
A fresh checkout must verify without editing data or touching result timestamps.

Preparation is a separate no-scoring activity. Maintenance mode deliberately
blocks plans/runs; doctor PASS means internally consistent, not evidence that
the next positive-control experiment has already been implemented or passed.
STOP/PAUSE, one pending plan, locks, resource limits, source audit and scientific
invalidity gates remain mandatory. At most one bounded deliverable per wake.
