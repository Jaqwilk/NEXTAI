"""Versioned, protected benchmark implementations."""

