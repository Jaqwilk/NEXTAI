import os,sys,time
from pathlib import Path
ready,heartbeat=map(Path,sys.argv[1:3])
heartbeat.write_text('0',encoding='ascii')
pending=ready.with_suffix('.pending')
pending.write_text(str(os.getpid()),encoding='ascii')
pending.replace(ready)
deadline=time.monotonic()+60.
counter=0
while time.monotonic()<deadline:
    counter+=1
    heartbeat.write_text(str(counter),encoding='ascii')
    time.sleep(.01)
